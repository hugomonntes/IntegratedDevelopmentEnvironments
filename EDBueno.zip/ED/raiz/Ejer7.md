# PROGRAMACIÓN


Aprendiendo las bases de lenguaje **Java**


### Los primeros pasos


Veremos _conceptos_ importantes como:


* Datos
* Variables
* Algoritmos y más...


Un ejemplo
```java
    int numero;


    System.out.print("Dime un número entero: ");
    numero = sc.nextInt();
    System.out.println();
    if (numero>0){
        System.out.println("El número es positivo");
    }
```
A fin de curso subiremos todo a [github](https://github.com/)


### Consejos para aprender a programar
1. Programa
2. Programa
3. Programa con un poco más
4. Comete errores programando
5. Corrige y entiende los errores
6. Programa un poquito más
